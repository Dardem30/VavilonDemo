create view vw_profile_info (userid, info, username, countannouncements, averagerate, countcomments, photo) as
SELECT u.userid,
       u.info,
       concat(u.firstname, ' ', u.lastname) AS username,
       (SELECT count(*) AS count
        FROM announcement a
        WHERE a.userid = u.userid)          AS countannouncements,
       (SELECT sum(a.rating) / count(*)::double precision
        FROM announcement a
        WHERE a.userid = u.userid)          AS averagerate,
       (SELECT count(*) AS count
        FROM comment c
        WHERE c.userid = u.userid)          AS countcomments,
       u.photo
FROM "user" u;

alter table vw_profile_info
    owner to postgres;

