create view vw_comment_overview (commentid, text, createtime, userid, username, announcementid, rate, rootcommentid) as
SELECT c.commentid,
       c.text,
       c.createtime,
       c.userid,
       concat(u.firstname, ' ', u.lastname) AS username,
       c.announcementid,
       arh.rate,
       c.rootcommentid
FROM comment c
         JOIN "user" u ON c.userid = u.userid
         JOIN announcement a ON a.announcementid = c.announcementid
         LEFT JOIN announcementratehistory arh ON arh.userid = u.userid AND arh.announcementid = a.announcementid;

alter table vw_comment_overview
    owner to postgres;

