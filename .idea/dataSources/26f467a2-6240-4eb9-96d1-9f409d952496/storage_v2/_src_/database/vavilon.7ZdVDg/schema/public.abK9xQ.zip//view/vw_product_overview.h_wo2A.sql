create view vw_product_overview(productid, name, description, category, categoryid, image, userid) as
SELECT p.productid,
       p.name,
       CASE
           WHEN length(p.description::text) > 200
               THEN concat("substring"(p.description::text, 0, 200), '...')::character varying
           ELSE p.description
           END              AS description,
       pc.name              AS category,
       pc.productcategoryid AS categoryid,
       a.fileid             AS image,
       p.userid
FROM product p
         JOIN productcategory pc ON pc.productcategoryid = p.productcategoryid
         LEFT JOIN attachment a ON a.productid = p.productid AND a.main = true;

alter table vw_product_overview
    owner to postgres;

