create view vw_product_overview(productid, name, description, category, categoryid) as
SELECT p.productid,
       p.name,
       p.description,
       pc.name              AS category,
       pc.productcategoryid AS categoryid
FROM product p
         JOIN productcategory pc ON pc.productcategoryid = p.productcategoryid;

alter table vw_product_overview
    owner to postgres;

