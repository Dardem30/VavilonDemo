create view vw_announcement_overview
            (announcementid, image, productname, text, moderationstatusid, price, currencysign, measurecode, measure,
             userid, moderationstatusname, username, ownerphoto, rating, readyforreview)
as
SELECT a.announcementid,
       att.fileid                           AS image,
       p.name                               AS productname,
       CASE
           WHEN length(a.text::text) > 200 THEN concat("substring"(a.text::text, 0, 200), '...')::character varying
           ELSE a.text
           END                              AS text,
       a.moderationstatusid,
       a.price,
       a.currencysign,
       m.measurecode,
       m.name                               AS measure,
       a.userid,
       ms.name                              AS moderationstatusname,
       concat(u.firstname, ' ', u.lastname) AS username,
       u.photo                              AS ownerphoto,
       a.rating,
       a.readyforreview
FROM announcement a
         JOIN product p ON a.productid = p.productid
         JOIN moderationstatus ms ON ms.moderationstatusid = a.moderationstatusid
         JOIN measure m ON a.measurecode::text = m.measurecode::text
         JOIN "user" u ON u.userid = a.userid
         LEFT JOIN attachment att ON att.productid = p.productid AND att.main = true;

alter table vw_announcement_overview
    owner to postgres;

