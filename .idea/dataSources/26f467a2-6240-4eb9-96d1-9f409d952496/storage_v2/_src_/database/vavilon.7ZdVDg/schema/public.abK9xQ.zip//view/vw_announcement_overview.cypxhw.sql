create view vw_announcement_overview(announcementid, image, productname, text) as
SELECT a.announcementid,
       (SELECT att.fileid
        FROM attachment att
        WHERE att.productid = a.productid
          AND att.main = true) AS image,
       p.name                  AS productname,
       a.text
FROM announcement a
         JOIN product p ON a.productid = p.productid;

alter table vw_announcement_overview
    owner to postgres;

